#!/bin/bash
for i in $(seq 1 5); do
    (
        tftp 127.0.0.1 -c get /aa/initrd.img /tmp/test_initrd-$i.img 2>/dev/null
        echo "第 $i 个完成"
    ) &
done
wait
echo "全部完成"
