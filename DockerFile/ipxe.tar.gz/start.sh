

pkill dhcpd
/usr/sbin/dhcpd -f -cf /etc/dhcp/dhcpd.conf -lf /var/run/dhcpd/dhcpd.leases &



pkill tftp
 /usr/sbin/in.tftpd -L -s /var/lib/tftpboot   -vvv --blocksize 1468 -a :69 &


/opt/nginx/sbin/nginx -s stop
/opt/nginx/sbin/nginx 
